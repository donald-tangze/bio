Phase 2: (/opt/iaspec/payment-hub)  http://10.3.60.47:8080/payment-console/showLogin.action    

Phase 1: (/opt/iaspec/payment-hub-pre-prod) http://10.3.60.47:9080/payment-console/showLogin.action



1. Property Management,  properties file and database property table

   dynamic reload,  How to implement it. provide api web service to request to update, write, read property [name : value].

2. MQ and Redis, com.ibm.mq.allclient, spring-integration-redis
3. Excel export, hundred columns,  write Excel, Jax      opencsv
4. handle XML, use library JAB
5. Database: db2, spring-data, spring-jdbc, spring, com.ibm.db2,  hibernate-core, spring-orm
6. old-generation format file - txt, transformation between txt and object, fixedlength library
7. web restful api, swagger, spring restful, spring-boot-starter-web